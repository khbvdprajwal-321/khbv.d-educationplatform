import { useMemo, useState } from 'react';
import { ArrowLeft, Clock, ClipboardList, GraduationCap, ListChecks, Sparkles } from 'lucide-react';
import { navigate } from '@/App';
import { AppHeader } from '@/components/AppHeader';
import { MockTest } from '@/components/practice/MockTest';
import { TwoQuestionSet } from '@/components/practice/TwoQuestionSet';
import { useAuth } from '@/lib/auth-context';
import {
  ASSIGNMENT_SET_SIZE,
  DAILY_SET_SIZE,
  MOCK_SECONDS_PER_QUESTION,
  MOCK_TEST_SIZE,
  PRACTICE_TRACKS,
  availableYears,
  filterByYear,
  isPracticeMode,
  isPracticeTrack,
  pickRandomQuestions,
  type PracticeMode,
} from '@/lib/practice-engine';
import { usePracticeQuestions } from '@/lib/use-practice-questions';
import type { PracticeTrack } from '@/lib/types';

interface PracticePageProps {
  track: string;
  mode: string;
}

const MODES: { id: PracticeMode; label: string; icon: typeof ListChecks }[] = [
  { id: 'daily', label: 'Daily Learn', icon: ListChecks },
  { id: 'assignment', label: 'Assignments', icon: ClipboardList },
  { id: 'mock', label: 'Mock Test', icon: Clock },
];

export function PracticePage({ track, mode: modeParam }: PracticePageProps) {
  const { profile } = useAuth();
  const defaultTrack: PracticeTrack = profile?.exam_stream ?? (profile?.user_type === 'degree' ? 'degree' : 'cet');
  const activeTrack: PracticeTrack = isPracticeTrack(track) ? track : defaultTrack;

  const mode: PracticeMode = isPracticeMode(modeParam) ? modeParam : 'daily';
  const [year, setYear] = useState<number | null>(null);
  const [setSeed, setSetSeed] = useState(0);
  const [mockStarted, setMockStarted] = useState(false);
  const { questions, loading, error } = usePracticeQuestions(activeTrack);

  const pool = useMemo(() => filterByYear(questions, year), [questions, year]);
  const years = useMemo(() => availableYears(questions), [questions]);
  const previousYearPool = useMemo(() => pool.filter((question) => question.year_asked !== null), [pool]);
  const dailyQuestions = useMemo(() => pickRandomQuestions(pool, DAILY_SET_SIZE), [pool, setSeed]);
  const assignmentQuestions = useMemo(
    () => pickRandomQuestions(previousYearPool.length >= ASSIGNMENT_SET_SIZE ? previousYearPool : pool, ASSIGNMENT_SET_SIZE),
    [previousYearPool, pool, setSeed],
  );
  const mockQuestions = useMemo(() => pickRandomQuestions(pool, MOCK_TEST_SIZE), [pool, setSeed]);

  const trackLabel = PRACTICE_TRACKS.find((item) => item.id === activeTrack)?.label ?? 'Practice';
  const enoughForMock = pool.length >= MOCK_TEST_SIZE;

  const renderContent = () => {
    if (loading) {
      return (
        <div className="card p-10 flex justify-center">
          <div className="w-10 h-10 border-4 border-teal-200 border-t-teal-600 rounded-full animate-spin" />
        </div>
      );
    }
    if (error) {
      return (
        <div className="card p-8 text-center">
          <p className="text-slate-700 font-semibold mb-2">Questions are unavailable</p>
          <p className="text-sm text-slate-500">{error}</p>
        </div>
      );
    }
    if (questions.length === 0) {
      return (
        <div className="card p-8 text-center">
          <GraduationCap className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-600">Questions for {trackLabel} are coming soon.</p>
        </div>
      );
    }

    if (mode === 'mock') {
      if (!mockStarted) {
        return (
          <div className="card p-6 sm:p-8 text-center animate-fade-in">
            <div className="w-14 h-14 rounded-2xl bg-teal-50 flex items-center justify-center mx-auto mb-4">
              <Clock className="w-7 h-7 text-teal-700" />
            </div>
            <h2 className="text-xl font-heading font-bold text-slate-900 mb-2">{trackLabel} Mock Test</h2>
            <p className="text-sm text-slate-500 mb-6">
              {MOCK_TEST_SIZE} questions, {MOCK_SECONDS_PER_QUESTION} seconds each. Your full answer review appears when you finish.
            </p>
            {enoughForMock ? (
              <button type="button" onClick={() => setMockStarted(true)} className="btn-primary w-full py-3">Start Mock Test</button>
            ) : (
              <p className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-3">
                This filter has only {pool.length} questions. Choose "All years" to start a {MOCK_TEST_SIZE}-question mock test.
              </p>
            )}
          </div>
        );
      }
      return (
        <MockTest
          key={setSeed}
          questions={mockQuestions}
          onRetake={() => { setSetSeed((seed) => seed + 1); }}
          onExit={() => { setMockStarted(false); setSetSeed((seed) => seed + 1); }}
        />
      );
    }

    if (pool.length < DAILY_SET_SIZE) {
      return (
        <div className="card p-8 text-center">
          <p className="text-slate-600">No questions match this year yet. Choose "All years" to continue.</p>
        </div>
      );
    }

    const isAssignment = mode === 'assignment';
    const setQuestions = isAssignment ? assignmentQuestions : dailyQuestions;
    return (
      <div className="space-y-4">
        <div className="card p-4 bg-teal-50 border-teal-200">
          <p className="text-sm text-teal-900">
            {isAssignment
              ? `Assignment: answer these ${ASSIGNMENT_SET_SIZE} questions, then press Finish to see your results.`
              : `Daily learning: answer these ${DAILY_SET_SIZE} questions, then press Finish to see your results.`}
          </p>
        </div>
        <TwoQuestionSet
          key={`${mode}-${year ?? 'all'}-${setSeed}`}
          questions={setQuestions}
          onNewSet={() => setSetSeed((seed) => seed + 1)}
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <button
          type="button"
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to dashboard
        </button>

        <div className="card p-6 mb-6 gradient-hero text-white">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20">
              <Sparkles className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-heading font-bold">{trackLabel} Practice</h1>
              <p className="text-teal-100/90 text-sm mt-0.5">Daily learning, assignments and timed mock tests</p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {PRACTICE_TRACKS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => navigate(`/practice/${item.id}`)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                item.id === activeTrack ? 'bg-teal-700 text-white' : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-2 mb-4">
          {MODES.map((item) => {
            const Icon = item.icon;
            const active = item.id === mode;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate(`/practice/${activeTrack}/${item.id}`)}
                className={`p-3 rounded-xl text-sm font-semibold flex flex-col sm:flex-row items-center justify-center gap-2 transition-all ${
                  active ? 'bg-white border-2 border-teal-600 text-teal-800 shadow-sm' : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <Icon className="w-4 h-4" /> {item.label}
              </button>
            );
          })}
        </div>

        {years.length > 0 && (
          <div className="mb-6">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Previous year papers</p>
            <div className="flex flex-wrap gap-2">
              {[null, ...years].map((option) => {
                const active = option === year;
                return (
                  <button
                    key={option ?? 'all'}
                    type="button"
                    onClick={() => { setYear(option); setSetSeed((seed) => seed + 1); setMockStarted(false); }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      active ? 'bg-amber-500 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-amber-300'
                    }`}
                  >
                    {option === null ? 'All years' : option}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {renderContent()}
      </div>
    </div>
  );
}
