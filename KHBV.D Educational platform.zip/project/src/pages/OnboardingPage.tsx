import { useState } from 'react';
import { GraduationCap, Briefcase, ArrowRight, BookOpen, Award, Wrench, Cpu, HardHat } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { navigate } from '@/App';
import { AppHeader } from '@/components/AppHeader';
import { streamSubjects, degreeTypes, getDepartmentsForDegree } from '@/lib/question-engine';

export function OnboardingPage() {
  const { profile, refreshProfile } = useAuth();
  const savedPath = typeof window !== 'undefined' ? window.localStorage.getItem('khbvd_selected_path') : null;
  const [userType, setUserType] = useState<'puc' | 'degree' | null>(savedPath && ['cet', 'neet', 'jee'].includes(savedPath) ? 'puc' : savedPath === 'degree' ? 'degree' : null);
  const [examStream, setExamStream] = useState<string>(savedPath && ['cet', 'neet', 'jee'].includes(savedPath) ? savedPath : '');
  const [degreeType, setDegreeType] = useState<string>('');
  const [department, setDepartment] = useState<string>('');
  const [semester, setSemester] = useState(1);
  const [pucYear, setPucYear] = useState<number | null>(null);
  const [experienceLevel, setExperienceLevel] = useState<'fresher' | 'experienced' | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!userType) return;
    if (userType === 'puc' && (!examStream || !pucYear)) return;
    if (userType === 'degree' && !degreeType) return;
    if (userType === 'degree' && degreeType === 'BE' && !department) return;

    const degreeData = degreeTypes.find((d) => d.id === degreeType);
    const maxSem = degreeData?.semesters || 8;

    setLoading(true);
    const { error } = await supabase.from('profiles').update({
      user_type: userType,
      exam_stream: userType === 'puc' ? examStream : null,
      degree_type: userType === 'degree' ? degreeType : null,
      department: userType === 'degree' && degreeType === 'BE' ? department : null,
      experience_level: userType === 'degree' ? experienceLevel : null,
      current_semester: Math.min(semester, maxSem),
      puc_year: userType === 'puc' ? pucYear : null,
    }).eq('id', profile!.id);

    if (error) {
      setLoading(false);
      return;
    }

    window.localStorage.removeItem('khbvd_selected_path');
    await refreshProfile();
    navigate('/dashboard');
  };

  const selectedDegree = degreeTypes.find((d) => d.id === degreeType);
  const maxSemesters = selectedDegree?.semesters || 8;
  const semesterList = Array.from({ length: maxSemesters }, (_, i) => i + 1);
  const availableDepartments = degreeType ? getDepartmentsForDegree(degreeType) : [];

  const degreeCards = [
    { id: 'BE', name: 'B.E. / B.Tech', desc: 'IT & Non-IT career paths', icon: HardHat, duration: '4 years, 8 semesters' },
    { id: 'MBA', name: 'MBA & Business', desc: 'HR, Operations, Finance, Product', icon: Briefcase, duration: '2 years, 4 semesters' },
    { id: 'Diploma', name: 'Diploma', desc: 'Government jobs & technical roles', icon: Wrench, duration: '3 years, 6 semesters' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />

      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-heading font-bold text-slate-900 mb-2">
            Tell us about yourself
          </h1>
          <p className="text-slate-500">
            We'll personalize your learning experience based on your path.
          </p>
        </div>

        {/* Step 1: Choose path */}
        <div className="mb-8">
          <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
            1. Choose your path
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setUserType('puc')}
              className={`card p-6 text-left transition-all duration-200 ${userType === 'puc' ? 'ring-2 ring-teal-500 border-teal-300' : 'hover:border-slate-300'}`}
            >
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-3">
                <GraduationCap className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-1">PUC Student</h3>
              <p className="text-sm text-slate-500">Preparing for CET, NEET, or JEE</p>
            </button>

            <button
              onClick={() => setUserType('degree')}
              className={`card p-6 text-left transition-all duration-200 ${userType === 'degree' ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:border-slate-300'}`}
            >
              <div className="w-12 h-12 rounded-xl bg-cyan-50 flex items-center justify-center mb-3">
                <Briefcase className="w-6 h-6 text-cyan-600" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-1">Degree Student</h3>
              <p className="text-sm text-slate-500">Career mapping & skill analysis</p>
            </button>
          </div>
        </div>

        {/* Step 2: PUC stream */}
        {userType === 'puc' && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              2. Select your exam stream
            </h2>
            <div className="space-y-3">
              {[
                { id: 'cet', name: 'CET', desc: 'Maths, Physics, Chemistry, Biology', subjects: streamSubjects.cet },
                { id: 'neet', name: 'NEET', desc: 'Biology, Chemistry, Physics', subjects: streamSubjects.neet },
                { id: 'jee', name: 'JEE', desc: 'Maths, Physics, Chemistry, Biology', subjects: streamSubjects.jee },
              ].map((stream) => (
                <button
                  key={stream.id}
                  onClick={() => setExamStream(stream.id)}
                  className={`card w-full p-4 text-left flex items-center justify-between transition-all duration-200 ${examStream === stream.id ? 'ring-2 ring-teal-500 border-teal-300' : 'hover:border-slate-300'}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center">
                      <BookOpen className="w-5 h-5 text-teal-600" />
                    </div>
                    <div>
                      <h3 className="font-heading font-bold">{stream.name}</h3>
                      <p className="text-sm text-slate-500">{stream.desc}</p>
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    {stream.subjects.map((s) => (
                      <span key={s} className="px-2 py-0.5 bg-slate-100 text-slate-600 text-xs font-medium rounded-md">
                        {s.slice(0, 4)}
                      </span>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2b: PUC year */}
        {userType === 'puc' && examStream && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              3. Current PUC Year
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setPucYear(1)}
                className={`card p-6 text-center transition-all duration-200 ${pucYear === 1 ? 'ring-2 ring-teal-500 border-teal-300' : 'hover:border-slate-300'}`}
              >
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-heading font-bold text-teal-600">1</span>
                </div>
                <h3 className="font-heading font-bold text-lg mb-1">1st PUC</h3>
                <p className="text-sm text-slate-500">First year</p>
              </button>
              <button
                onClick={() => setPucYear(2)}
                className={`card p-6 text-center transition-all duration-200 ${pucYear === 2 ? 'ring-2 ring-teal-500 border-teal-300' : 'hover:border-slate-300'}`}
              >
                <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl font-heading font-bold text-teal-600">2</span>
                </div>
                <h3 className="font-heading font-bold text-lg mb-1">2nd PUC</h3>
                <p className="text-sm text-slate-500">Second year</p>
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Degree type — 3 options */}
        {userType === 'degree' && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              2. Select your degree
            </h2>
            <div className="space-y-3">
              {degreeCards.map((deg) => {
                const Icon = deg.icon;
                return (
                  <button
                    key={deg.id}
                    onClick={() => { setDegreeType(deg.id); setDepartment(''); setSemester(1); }}
                    className={`card w-full p-5 text-left flex items-center justify-between transition-all duration-200 ${degreeType === deg.id ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:border-slate-300'}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-cyan-50 flex items-center justify-center">
                        <Icon className="w-6 h-6 text-cyan-600" />
                      </div>
                      <div>
                        <h3 className="font-heading font-bold text-lg">{deg.name}</h3>
                        <p className="text-sm text-slate-500">{deg.desc}</p>
                        <p className="text-xs text-slate-400 mt-0.5">{deg.duration}</p>
                      </div>
                    </div>
                    {degreeType === deg.id && <ArrowRight className="w-5 h-5 text-cyan-600" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 2b: Department selection for B.E. */}
        {userType === 'degree' && degreeType === 'BE' && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              3. Select your department
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {availableDepartments.map((dept) => (
                <button
                  key={dept.id}
                  onClick={() => setDepartment(dept.id)}
                  className={`card p-4 text-left transition-all duration-200 ${department === dept.id ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:border-slate-300'}`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="w-4 h-4 text-cyan-600" />
                    <h3 className="font-semibold text-sm">{dept.name}</h3>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {dept.subjects.slice(0, 4).map((s) => (
                      <span key={s} className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-xs rounded">{s.slice(0, 8)}</span>
                    ))}
                    {dept.subjects.length > 4 && <span className="text-xs text-slate-400">+{dept.subjects.length - 4}</span>}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Experience level for degree students */}
        {userType === 'degree' && degreeType && (degreeType !== 'BE' || department) && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              {degreeType === 'BE' ? '4' : '3'}. Experience level
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setExperienceLevel('fresher')}
                className={`card p-5 text-center transition-all duration-200 ${experienceLevel === 'fresher' ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:border-slate-300'}`}
              >
                <div className="w-10 h-10 rounded-xl bg-cyan-50 flex items-center justify-center mx-auto mb-2">
                  <GraduationCap className="w-5 h-5 text-cyan-600" />
                </div>
                <h3 className="font-heading font-bold mb-1">Fresher</h3>
                <p className="text-xs text-slate-500">Default 12 LPA package</p>
              </button>
              <button
                onClick={() => setExperienceLevel('experienced')}
                className={`card p-5 text-center transition-all duration-200 ${experienceLevel === 'experienced' ? 'ring-2 ring-cyan-500 border-cyan-300' : 'hover:border-slate-300'}`}
              >
                <div className="w-10 h-10 rounded-xl bg-cyan-50 flex items-center justify-center mx-auto mb-2">
                  <Briefcase className="w-5 h-5 text-cyan-600" />
                </div>
                <h3 className="font-heading font-bold mb-1">Experienced</h3>
                <p className="text-xs text-slate-500">Enter your package choice</p>
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Semester — dynamic based on degree */}
        {userType && (userType === 'puc' ? examStream && pucYear : degreeType && (degreeType !== 'BE' || department)) && (
          <div className="mb-8 animate-fade-in-up">
            <h2 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">
              {userType === 'degree' ? (degreeType === 'BE' ? '5' : '4') : '4'}. Current semester
            </h2>
            <div className="flex flex-wrap gap-2">
              {semesterList.map((sem) => (
                <button
                  key={sem}
                  onClick={() => setSemester(sem)}
                  className={`w-12 h-12 rounded-xl font-bold transition-all duration-200 ${semester === sem ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300'}`}
                >
                  {sem}
                </button>
              ))}
            </div>
          </div>
        )}

        {userType && (userType === 'puc' ? examStream && pucYear : degreeType && (degreeType !== 'BE' || department)) && (
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed animate-fade-in-up"
          >
            {loading ? 'Setting up...' : 'Continue to Dashboard'}
            {!loading && <ArrowRight className="w-5 h-5" />}
          </button>
        )}
      </div>
    </div>
  );
}
