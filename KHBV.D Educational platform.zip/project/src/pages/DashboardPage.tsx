import { useState, useEffect, useRef } from 'react';
import { GraduationCap, BookOpen, Brain, TrendingUp, Clock, Award, ArrowRight, BarChart3, FileText, Briefcase, Target, Flame, CheckCircle, Bell, BellRing, X } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/lib/supabase';
import { navigate } from '@/App';
import { AppHeader } from '@/components/AppHeader';
import { degreeTypes, homeworkPattern, getDepartmentSubjects, departments } from '@/lib/question-engine';
import type { ExamAttempt, HomeworkTracking } from '@/lib/types';

const PUC_EXAMS = [
  { id: 'cet', name: 'CET', detail: 'Karnataka CET entrance preparation' },
  { id: 'neet', name: 'NEET', detail: 'NEET medical entrance preparation' },
  { id: 'jee', name: 'JEE', detail: 'JEE engineering entrance preparation' },
];

export function DashboardPage() {
  const { profile } = useAuth();
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [homework, setHomework] = useState<HomeworkTracking[]>([]);
  const [streak, setStreak] = useState(0);
  const [showAssignmentReminder, setShowAssignmentReminder] = useState(false);
  const reminderTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!profile) return;
    loadData();
  }, [profile]);

  async function loadData() {
    const [examRes, hwRes] = await Promise.all([
      supabase.from('exam_attempts').select('*').eq('user_id', profile!.id).order('started_at', { ascending: false }).limit(10),
      supabase.from('homework_tracking').select('*').eq('user_id', profile!.id).order('assigned_date', { ascending: false }).limit(7),
    ]);
    setAttempts(examRes.data as ExamAttempt[] || []);
    setHomework(hwRes.data as HomeworkTracking[] || []);

    // Calculate streak
    const completedHw = (hwRes.data || []).filter((h: HomeworkTracking) => h.status === 'completed');
    setStreak(completedHw.length);

    // Check if today's homework/assignment is pending — show reminder
    const today = new Date().toISOString().slice(0, 10);
    const todayHw = (hwRes.data || []).find((h: HomeworkTracking) => h.assigned_date === today);
    if (!todayHw || todayHw.status !== 'completed') {
      setTimeout(() => setShowAssignmentReminder(true), 2000);
    }
  }

  // Request notification permission for assignment alarms
  useEffect(() => {
    if (profile?.user_type === 'puc' && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, [profile?.user_type]);

  // Assignment reminder notification
  useEffect(() => {
    if (showAssignmentReminder && profile?.user_type === 'puc' && 'Notification' in window && Notification.permission === 'granted') {
      new Notification('KHBV.D Assignment Reminder', {
        body: 'Your daily homework assignment is waiting! Keep your streak alive.',
        icon: '/vite.svg',
      });
    }
  }, [showAssignmentReminder, profile?.user_type]);

  if (!profile) return null;

  const isPUC = profile.user_type === 'puc';
  const isSchool = profile.user_type === 'school';
  const schoolSubjects = [profile.first_language || 'First Language', profile.second_language || 'Second Language', profile.third_language || 'Third Language', 'Mathematics', 'Science', 'Social Science'];
  const subjects = isSchool ? schoolSubjects : [];
  const departmentSubjects = !isPUC && profile.department ? getDepartmentSubjects(profile.department) : [];
  const departmentName = departments.find((d) => d.id === profile.department)?.name;
  const avgScore = attempts.length > 0
    ? Math.round(attempts.reduce((sum, a) => sum + (a.score_percentage || 0), 0) / attempts.length)
    : 0;
  const totalExams = attempts.length;

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />

      {/* Assignment reminder banner */}
      {showAssignmentReminder && isPUC && (
        <div className="sticky top-16 z-40 bg-gradient-to-r from-amber-500 to-orange-500 text-white animate-fade-in-down">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center gap-3">
            <BellRing className="w-5 h-5 flex-shrink-0 animate-bounce" />
            <p className="text-sm font-semibold flex-1">
              Assignment Reminder: Your daily homework is waiting!
            </p>
            <button
              onClick={() => navigate(`/practice/${profile.exam_stream || 'cet'}`)}
              className="px-3 py-1.5 bg-white text-orange-600 font-bold rounded-lg text-xs hover:bg-orange-50 transition-colors"
            >
              Start Now
            </button>
            <button onClick={() => setShowAssignmentReminder(false)} className="p-1 hover:bg-white/20 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome banner */}
        <div className="card p-6 mb-8 overflow-hidden relative gradient-hero text-white">
          <div className="absolute top-0 right-0 w-64 h-64 bg-teal-400/20 rounded-full blur-3xl -mr-20 -mt-20" />
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-heading font-bold mb-1">
                Welcome back, {profile.full_name.split(' ')[0]}!
              </h1>
              <p className="text-teal-100/80 text-sm">
                {isPUC
                  ? `${profile.exam_stream?.toUpperCase()} preparation — keep up the momentum!`
                  : isSchool
                    ? `Class ${profile.school_class || 10} state syllabus — keep up the momentum!`
                    : `${degreeTypes.find((d) => d.id === profile.degree_type)?.name || 'Degree'} — Semester ${profile.current_semester}`}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-center bg-white/10 rounded-xl px-4 py-2 border border-white/20">
                <div className="text-2xl font-bold">{streak}</div>
                <div className="text-xs text-teal-200/70">Day streak</div>
              </div>
              {profile.is_premium && (
                <div className="text-center bg-amber-400/20 rounded-xl px-4 py-2 border border-amber-300/30">
                  <Award className="w-5 h-5 text-amber-300 mx-auto" />
                  <div className="text-xs text-amber-200/80 mt-0.5">Premium</div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: FileText, label: 'Exams Taken', value: totalExams, color: 'teal' },
            { icon: Target, label: 'Avg Score', value: `${avgScore}%`, color: 'cyan' },
            { icon: Flame, label: 'Day Streak', value: streak, color: 'orange' },
            { icon: CheckCircle, label: 'Homework Done', value: homework.filter((h) => h.status === 'completed').length, color: 'emerald' },
          ].map((stat) => (
            <div key={stat.label} className="card p-5">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 bg-${stat.color}-50`}>
                <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
              </div>
              <div className="text-2xl font-heading font-bold text-slate-900">{stat.value}</div>
              <div className="text-sm text-slate-500">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main content area */}
          <div className="lg:col-span-2 space-y-6">
            {/* PUC: Subject grid */}
            {isSchool && (
              <div>
                <h2 className="font-heading font-bold text-lg mb-4">Your Subjects</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {subjects.map((subject) => (
                    <button
                      key={subject}
                      onClick={() => navigate(`/subject/${encodeURIComponent(subject)}`)}
                      className="card p-5 text-left hover:shadow-lg hover:border-teal-200 transition-all duration-200 group"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center group-hover:bg-teal-100 transition-colors">
                          <BookOpen className="w-5 h-5 text-teal-600" />
                        </div>
                        <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-teal-600 group-hover:translate-x-1 transition-all" />
                      </div>
                      <h3 className="font-heading font-bold text-base mb-1">{subject}</h3>
                      <p className="text-sm text-slate-500">Exam, Learn, Homework, Assignment</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {isPUC && (
              <div>
                <h2 className="font-heading font-bold text-lg mb-4">Choose Your Exam</h2>
                <div className="grid sm:grid-cols-3 gap-4">
                  {PUC_EXAMS.map((exam) => (
                    <button
                      key={exam.id}
                      onClick={() => navigate(`/practice/${exam.id}`)}
                      className="card p-5 text-left hover:shadow-lg hover:border-teal-200 transition-all duration-200 group"
                    >
                      <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center mb-3 group-hover:bg-teal-100 transition-colors">
                        <GraduationCap className="w-5 h-5 text-teal-600" />
                      </div>
                      <h3 className="font-heading font-bold text-base mb-1">{exam.name}</h3>
                      <p className="text-sm text-slate-500">{exam.detail}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {!isPUC && !isSchool && (
              <div>
                <h2 className="font-heading font-bold text-lg mb-4">Choose Your Degree</h2>
                <div className="grid sm:grid-cols-3 gap-4 mb-8">
                  {degreeTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => navigate('/practice/degree')}
                      className="card p-5 text-left hover:shadow-lg hover:border-cyan-200 transition-all duration-200 group"
                    >
                      <div className="w-10 h-10 rounded-xl bg-cyan-50 flex items-center justify-center mb-3 group-hover:bg-cyan-100 transition-colors">
                        <Briefcase className="w-5 h-5 text-cyan-600" />
                      </div>
                      <h3 className="font-heading font-bold text-base mb-1">{type.name}</h3>
                      <p className="text-sm text-slate-500">{type.semesters} semesters</p>
                    </button>
                  ))}
                </div>
                <h2 className="font-heading font-bold text-lg mb-4">Degree Practice</h2>
                <div className="grid sm:grid-cols-3 gap-4">
                  {[
                    { mode: 'daily', title: 'Learn', detail: 'Five questions with answers and explanations', icon: BookOpen, tile: 'bg-teal-50 group-hover:bg-teal-100', iconColor: 'text-teal-600' },
                    { mode: 'assignment', title: 'Assignment', detail: 'Three questions for today, with answers after submitting', icon: FileText, tile: 'bg-cyan-50 group-hover:bg-cyan-100', iconColor: 'text-cyan-600' },
                    { mode: 'mock', title: 'Mock Test', detail: '20 questions, 20 seconds each, full review at the end', icon: Clock, tile: 'bg-amber-50 group-hover:bg-amber-100', iconColor: 'text-amber-600' },
                  ].map((section) => {
                    const Icon = section.icon;
                    return (
                      <button
                        key={section.mode}
                        onClick={() => navigate(`/practice/degree/${section.mode}`)}
                        className="card p-5 text-left hover:shadow-lg hover:border-teal-200 transition-all duration-200 group"
                      >
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-colors ${section.tile}`}>
                          <Icon className={`w-5 h-5 ${section.iconColor}`} />
                        </div>
                        <h3 className="font-heading font-bold text-base mb-1">{section.title}</h3>
                        <p className="text-sm text-slate-500">{section.detail}</p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Degree: Quick actions */}
            {!isPUC && !isSchool && (
              <div>
                <h2 className="font-heading font-bold text-lg mb-4">Your Career Hub</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <button
                    onClick={() => navigate('/degree')}
                    className="card p-5 text-left hover:shadow-lg hover:border-cyan-200 transition-all duration-200 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-cyan-50 flex items-center justify-center mb-3 group-hover:bg-cyan-100 transition-colors">
                      <Briefcase className="w-5 h-5 text-cyan-600" />
                    </div>
                    <h3 className="font-heading font-bold text-base mb-1">Career Map</h3>
                    <p className="text-sm text-slate-500">View roles mapped to your degree</p>
                  </button>
                  <button
                    onClick={() => navigate('/resume')}
                    className="card p-5 text-left hover:shadow-lg hover:border-teal-200 transition-all duration-200 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center mb-3 group-hover:bg-teal-100 transition-colors">
                      <Brain className="w-5 h-5 text-teal-600" />
                    </div>
                    <h3 className="font-heading font-bold text-base mb-1">Resume Analysis</h3>
                    <p className="text-sm text-slate-500">Upload resume for skill gap report</p>
                  </button>
                  <button
                    onClick={() => navigate('/assistant')}
                    className="card p-5 text-left hover:shadow-lg hover:border-amber-200 transition-all duration-200 group"
                  >
                    <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center mb-3 group-hover:bg-amber-100 transition-colors">
                      <Brain className="w-5 h-5 text-amber-600" />
                    </div>
                    <h3 className="font-heading font-bold text-base mb-1">KHBV.D Assistant</h3>
                    <p className="text-sm text-slate-500">Get routines, guidance, and motivation</p>
                  </button>
                </div>
              </div>
            )}

            {!isPUC && !isSchool && profile.degree_type === 'BE' && departmentSubjects.length > 0 && (
              <div>
                <div className="flex items-end justify-between mb-4">
                  <div>
                    <h2 className="font-heading font-bold text-lg">{departmentName || 'Department'} Subjects</h2>
                    <p className="text-sm text-slate-500 mt-1">Semester {profile.current_semester} · Coding and theory in one place</p>
                  </div>
                  <span className="text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-200 px-2.5 py-1 rounded-lg">{departmentSubjects.length} subjects</span>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  {departmentSubjects.map((subject) => (
                    <button
                      key={subject}
                      onClick={() => navigate(`/subject/${encodeURIComponent(subject)}`)}
                      className="card p-5 text-left hover:shadow-lg hover:border-teal-200 transition-all duration-200 group"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center group-hover:bg-teal-100 transition-colors">
                          <BookOpen className="w-5 h-5 text-teal-600" />
                        </div>
                        <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-teal-600 group-hover:translate-x-1 transition-all" />
                      </div>
                      <h3 className="font-heading font-bold text-base mb-1">{subject}</h3>
                      <p className="text-sm text-slate-500">Learn, Assignment, and Exam</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Recent attempts */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-heading font-bold text-lg">Recent Activity</h2>
                {attempts.length > 0 && (
                  <button className="text-sm text-teal-600 font-semibold hover:underline">View all</button>
                )}
              </div>
              {attempts.length === 0 ? (
                <div className="card p-8 text-center">
                  <BarChart3 className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-slate-500 text-sm">No exams taken yet. Start practicing!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {attempts.slice(0, 5).map((attempt) => (
                    <button
                      key={attempt.id}
                      onClick={() => navigate(`/results/${attempt.id}`)}
                      className="card w-full p-4 flex items-center justify-between hover:shadow-md transition-all text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${(attempt.score_percentage || 0) >= 70 ? 'bg-emerald-50' : (attempt.score_percentage || 0) >= 40 ? 'bg-amber-50' : 'bg-rose-50'}`}>
                          <span className={`text-sm font-bold ${(attempt.score_percentage || 0) >= 70 ? 'text-emerald-600' : (attempt.score_percentage || 0) >= 40 ? 'text-amber-600' : 'text-rose-600'}`}>
                            {Math.round(attempt.score_percentage || 0)}%
                          </span>
                        </div>
                        <div>
                          <p className="font-semibold text-sm text-slate-900">{attempt.subject}</p>
                          <p className="text-xs text-slate-500">
                            {attempt.correct_answers || 0}/{attempt.total_questions} correct — {new Date(attempt.started_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-slate-300" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Homework tracker */}
            {isPUC && (
              <div className="card p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-teal-600" />
                  <h3 className="font-heading font-bold">Homework Cycle</h3>
                </div>
                <div className="space-y-2">
                  {homeworkPattern.map((day) => {
                    const hw = homework.find((h) => h.cycle_day === day.day);
                    const completed = hw?.status === 'completed';
                    return (
                      <div key={day.day} className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                        <div className="flex items-center gap-2">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${completed ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-500'}`}>
                            {completed ? <CheckCircle className="w-4 h-4" /> : day.day}
                          </div>
                          <span className="text-sm text-slate-700">Day {day.day}</span>
                        </div>
                        <span className="text-xs text-slate-500">{day.questions} Q{day.questions > 1 ? 's' : ''}</span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-slate-400 mt-3 text-center">1 → 2 → 3 → 2 pattern</p>
              </div>
            )}

            {/* Upgrade card */}
            {!profile.is_premium && (
              <div className="card p-5 bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="w-5 h-5 text-amber-600" />
                  <h3 className="font-heading font-bold text-slate-900">Go Premium</h3>
                </div>
                <p className="text-sm text-slate-600 mb-4">
                  Unlock personalized roadmaps, detailed tracking, and unlimited practice exams.
                </p>
                <button
                  onClick={() => navigate('/pricing')}
                  className="w-full px-4 py-2.5 bg-amber-600 text-white font-semibold rounded-xl hover:bg-amber-700 transition-colors text-sm"
                >
                  Upgrade Now
                </button>
              </div>
            )}

            {/* Quick exam button */}
            {isSchool && subjects.length > 0 && (
              <div className="card p-5">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-teal-600" />
                  <h3 className="font-heading font-bold">Quick Practice</h3>
                </div>
                <p className="text-sm text-slate-500 mb-4">Jump into a 25-question timed exam.</p>
                <button
                  onClick={() => navigate(`/exam/${encodeURIComponent(subjects[0])}/subject`)}
                  className="btn-primary w-full text-sm"
                >
                  Start Practice Exam
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
