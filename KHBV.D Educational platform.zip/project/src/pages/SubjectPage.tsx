import { useState } from 'react';
import { ArrowLeft, BookOpen, CalendarDays, CheckCircle, ChevronLeft, ChevronRight, ClipboardList, Download, Eye, FileCheck2, FileText, GraduationCap, Lightbulb, LockKeyhole, Play, ScrollText, Sparkles, Trophy, X } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { navigate } from '@/App';
import { AppHeader } from '@/components/AppHeader';
import { getChapterLesson, getChapterQuestions, type SSLCChapter, type SSLCPaper } from '@/lib/sslc-content';
import { useSSLCContent } from '@/lib/use-sslc-content';

type Tab = 'syllabus' | 'learn' | 'assignment' | 'exam' | 'vault';
type ExamMode = 'mcq' | 'written';
type AssignmentQuestion = { id: string; marks: 1 | 2 | 3 | 5; question: string; answer: string; explanation: string; pinned?: boolean };

const markGroups: { marks: AssignmentQuestion['marks']; label: string; color: string }[] = [
  { marks: 1, label: '1 Mark MCQs', color: 'amber' },
  { marks: 2, label: '2 Marks Short Answers', color: 'sky' },
  { marks: 3, label: '3 Marks Analytical', color: 'teal' },
  { marks: 5, label: '5 Marks Long-form Answers', color: 'rose' },
];

function makeAssignments(chapter: SSLCChapter): AssignmentQuestion[] {
  return [
    { id: `${chapter.id}-1`, marks: 1, question: `What is the central focus of ${chapter.title}?`, answer: `${chapter.summary} The answer should name the core idea directly.`, explanation: `For a one-mark response, write the exact concept first and avoid adding unrelated details.`, pinned: true },
    { id: `${chapter.id}-2`, marks: 2, question: `Write two important points from ${chapter.title}.`, answer: chapter.key_points.slice(0, 2).join('. ') + '.', explanation: 'Use two separate points, each with a keyword and one supporting phrase.' },
    { id: `${chapter.id}-3`, marks: 3, question: `Explain how the key ideas in ${chapter.title} connect to one another.`, answer: `${chapter.key_points.join(' → ')}. This sequence shows how the chapter moves from the basic idea to application.`, explanation: 'Start with the principle, connect it to an example or consequence, and finish with the result.' },
    { id: `${chapter.id}-4`, marks: 5, question: `Write a complete board-style answer on ${chapter.title}.`, answer: `${chapter.summary} Develop the answer with these points: ${chapter.key_points.join('; ')}. Conclude by stating why the concept matters in the syllabus.`, explanation: 'A five-mark answer earns marks through a clear introduction, four relevant points, examples or working where applicable, and a concluding sentence.' },
  ];
}

export function SubjectPage({ subject }: { subject: string }) {
  const { profile } = useAuth();
  const { chapters, papers, loading, sourceError } = useSSLCContent(subject);
  const [tab, setTab] = useState<Tab>('syllabus');
  const [selectedChapterNumber, setSelectedChapterNumber] = useState(1);
  const [shownAnswers, setShownAnswers] = useState<Set<string>>(new Set());
  const [examMode, setExamMode] = useState<ExamMode>('mcq');
  const [examAnswers, setExamAnswers] = useState<Record<number, number>>({});
  const [examSubmitted, setExamSubmitted] = useState(false);
  const [selectedPaper, setSelectedPaper] = useState<SSLCPaper | null>(null);
  if (!profile) return null;

  const selectedChapter = chapters.find((chapter) => chapter.chapter_number === selectedChapterNumber) || chapters[0];
  const chapterQuestions = selectedChapter ? getChapterQuestions(selectedChapter) : [];
  const assignments = selectedChapter ? makeAssignments(selectedChapter) : [];
  const lesson = selectedChapter ? getChapterLesson(selectedChapter) : [];
  const tabs: { id: Tab; label: string; icon: typeof BookOpen }[] = [
    { id: 'syllabus', label: 'Syllabus', icon: ScrollText },
    { id: 'learn', label: 'Learn', icon: BookOpen },
    { id: 'assignment', label: 'Assignment', icon: ClipboardList },
    { id: 'exam', label: 'Exam', icon: FileCheck2 },
    { id: 'vault', label: 'Paper Vault', icon: FileText },
  ];

  const chooseChapter = (chapter: SSLCChapter, nextTab: Tab) => {
    setSelectedChapterNumber(chapter.chapter_number);
    setShownAnswers(new Set());
    setExamAnswers({});
    setExamSubmitted(false);
    setTab(nextTab);
  };

  const toggleAnswer = (id: string) => setShownAnswers((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });

  const downloadPaper = (paper: SSLCPaper) => {
    const content = [`KHBV.D Karnataka SSLC Paper`, `${paper.subject} · ${paper.title}`, '', paper.description, '', 'Sections:', ...paper.questions.map((question) => `${question.marks} marks — ${question.type}`)].join('\n');
    const url = URL.createObjectURL(new Blob([content], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `${paper.subject}-${paper.year}-${paper.paper_type}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const score = chapterQuestions.reduce((total, question, index) => total + (examAnswers[index] === question.correctAnswer ? 1 : 0), 0);

  return (
    <div className="min-h-screen bg-slate-50">
      <AppHeader />
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button onClick={() => navigate('/dashboard')} className="flex items-center gap-1 text-sm text-slate-500 hover:text-teal-700 mb-6"><ArrowLeft className="w-4 h-4" /> Back to Dashboard</button>
        <section className="card overflow-hidden mb-6 gradient-hero text-white">
          <div className="p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-5">
            <div className="flex items-center gap-4"><div className="w-14 h-14 rounded-2xl bg-white/10 border border-amber-300/50 flex items-center justify-center"><GraduationCap className="w-7 h-7 text-amber-300" /></div><div><p className="text-xs uppercase tracking-wider text-amber-200 font-semibold">Karnataka SSLC · Class {profile.school_class || 10}</p><h1 className="text-2xl sm:text-3xl font-heading font-bold mt-1">{subject}</h1><p className="text-sm text-teal-100/80 mt-1">Official sequence, guided learning, board practice, and papers.</p></div></div>
            <div className="hidden sm:flex items-center gap-2 text-sm text-amber-100"><Sparkles className="w-4 h-4" /> {chapters.length} chapters loaded</div>
          </div>
          <div className="px-4 sm:px-8 pb-4 overflow-x-auto"><div className="flex gap-2 min-w-max">{tabs.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setTab(id)} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${tab === id ? 'bg-amber-300 text-slate-950' : 'bg-white/10 text-white hover:bg-white/20'}`}><Icon className="w-4 h-4" />{label}</button>)}</div></div>
        </section>

        {sourceError && <div className="mb-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">{sourceError}</div>}
        {loading && <div className="card p-6 mb-5 text-sm text-slate-500">Loading the shared catalogue…</div>}

        {tab === 'syllabus' && <section className="grid lg:grid-cols-[1fr_300px] gap-6"><div className="card p-6"><div className="flex items-center gap-3 mb-5"><div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center"><ScrollText className="w-5 h-5 text-amber-600" /></div><div><h2 className="font-heading font-bold text-xl">Complete chapter sequence</h2><p className="text-sm text-slate-500">Select a chapter to open its detailed study workspace.</p></div></div><div className="space-y-3">{chapters.map((chapter) => <button key={chapter.id} onClick={() => chooseChapter(chapter, 'learn')} className={`w-full flex items-center gap-4 p-4 rounded-xl border text-left transition-colors ${selectedChapterNumber === chapter.chapter_number ? 'border-amber-400 bg-amber-50/60' : 'border-slate-200 hover:border-amber-300 hover:bg-amber-50/30'}`}><span className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center text-sm font-bold">{chapter.chapter_number}</span><span className="font-semibold text-slate-800 flex-1">{chapter.title}</span><ChevronRight className="w-4 h-4 text-slate-300" /></button>)}</div></div><div className="space-y-6"><div className="card p-5 bg-slate-950 text-white border-amber-500/50"><Lightbulb className="w-6 h-6 text-amber-300 mb-3" /><h3 className="font-heading font-bold mb-2">Three-pass method</h3><p className="text-sm text-slate-300 leading-relaxed">Read the concept, retrieve it without notes, then prove it in a timed answer.</p></div><div className="card p-5"><h3 className="font-heading font-bold mb-3">Chapter tools</h3><div className="space-y-3 text-sm text-slate-600"><p className="flex gap-2"><CheckCircle className="w-4 h-4 text-emerald-600" />Lesson explanation</p><p className="flex gap-2"><CheckCircle className="w-4 h-4 text-emerald-600" />Mark-wise assignment</p><p className="flex gap-2"><CheckCircle className="w-4 h-4 text-emerald-600" />MCQ and written exam</p><p className="flex gap-2"><CheckCircle className="w-4 h-4 text-emerald-600" />Previous paper vault</p></div></div></div></section>}

        {tab === 'learn' && selectedChapter && <section className="space-y-6"><ChapterHeader chapter={selectedChapter} /><div className="grid lg:grid-cols-[1fr_280px] gap-6"><div className="card p-6 sm:p-8"><p className="text-xs uppercase tracking-wider text-amber-600 font-semibold mb-2">Guided lesson</p><h2 className="text-2xl font-heading font-bold mb-6">{selectedChapter.title}</h2><div className="space-y-4">{lesson.map((step, index) => <div key={step} className="flex gap-4 p-4 rounded-xl border border-slate-200 bg-white"><span className="w-8 h-8 rounded-lg bg-slate-950 text-amber-300 flex items-center justify-center font-bold flex-shrink-0">{index + 1}</span><p className="text-slate-700 leading-relaxed">{step}</p></div>)}</div>{selectedChapter.literature.story_focus && <div className="mt-6 p-5 rounded-xl bg-amber-50 border border-amber-200"><p className="text-xs uppercase tracking-wider text-amber-700 font-semibold mb-2">Literature answer frame</p><p className="text-sm text-amber-950 leading-relaxed">{selectedChapter.literature.story_focus}</p><p className="text-sm text-amber-950 leading-relaxed mt-3">{selectedChapter.literature.poem_focus}</p></div>}</div><div className="card p-5 h-fit"><h3 className="font-heading font-bold mb-3">Key points</h3><ul className="space-y-3">{selectedChapter.key_points.map((point) => <li key={point} className="flex gap-2 text-sm text-slate-600"><span className="text-amber-500">•</span>{point}</li>)}</ul>{selectedChapter.formulas.length > 0 && <><h3 className="font-heading font-bold mt-6 mb-3">Formula / answer checklist</h3><ul className="space-y-3">{selectedChapter.formulas.map((formula) => <li key={formula} className="text-sm text-slate-600">{formula}</li>)}</ul></>}</div></div><ChapterPager chapters={chapters} selected={selectedChapter} onSelect={(chapter) => chooseChapter(chapter, 'learn')} /></section>}

        {tab === 'assignment' && selectedChapter && <section className="space-y-5"><ChapterHeader chapter={selectedChapter} /><div className="card p-5 bg-slate-950 text-white border-amber-500/50"><div className="flex items-center gap-3"><Trophy className="w-6 h-6 text-amber-300" /><div><p className="text-xs uppercase tracking-wider text-amber-300 font-semibold">Pinned repeated question</p><p className="font-semibold mt-1">{assignments[0].question}</p></div></div></div>{markGroups.map((group) => <div key={group.marks} className="card p-5"><div className="flex items-center justify-between gap-3 mb-4"><div><h2 className="font-heading font-bold text-lg">{group.label}</h2><p className="text-sm text-slate-500">Write first, then check the detailed answer.</p></div><span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-bold">{group.marks} marks</span></div>{assignments.filter((item) => item.marks === group.marks).map((item) => <QuestionCard key={item.id} item={item} shown={shownAnswers.has(item.id)} onToggle={() => toggleAnswer(item.id)} />)}</div>)}</section>}

        {tab === 'exam' && selectedChapter && <section className="space-y-5"><div className="card p-5 sm:p-6 bg-slate-950 text-white border-amber-500/50"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-wider text-amber-300 font-semibold">Exam controller</p><h2 className="text-2xl font-heading font-bold mt-1">{selectedChapter.title}</h2><p className="text-sm text-slate-300 mt-1">Choose a testing mode and get feedback immediately.</p></div><div className="flex gap-2"><button onClick={() => { setExamMode('mcq'); setExamSubmitted(false); }} className={`px-3 py-2 rounded-lg text-sm font-semibold ${examMode === 'mcq' ? 'bg-amber-300 text-slate-950' : 'bg-white/10 text-white'}`}>MCQ Test</button><button onClick={() => { setExamMode('written'); setExamSubmitted(false); }} className={`px-3 py-2 rounded-lg text-sm font-semibold ${examMode === 'written' ? 'bg-amber-300 text-slate-950' : 'bg-white/10 text-white'}`}>Written Sheet</button></div></div></div>{examMode === 'mcq' ? <div className="space-y-4">{chapterQuestions.map((question, index) => <div key={question.id} className="card p-5"><div className="flex items-center gap-2 mb-3"><span className="text-xs font-bold text-amber-700">Q{index + 1}</span><span className="text-xs text-slate-400">{question.difficulty} · {question.yearAsked}</span></div><p className="font-semibold text-slate-900 mb-4">{question.question}</p><div className="grid sm:grid-cols-2 gap-2">{question.options.map((option, optionIndex) => <button key={option} disabled={examSubmitted} onClick={() => setExamAnswers({ ...examAnswers, [index]: optionIndex })} className={`p-3 rounded-xl border text-left text-sm ${examAnswers[index] === optionIndex ? 'border-amber-500 bg-amber-50' : 'border-slate-200 hover:border-amber-300'} ${examSubmitted && optionIndex === question.correctAnswer ? 'border-emerald-500 bg-emerald-50' : ''}`}>{String.fromCharCode(65 + optionIndex)}. {option}</button>)}</div>{examSubmitted && <p className={`mt-4 text-sm ${examAnswers[index] === question.correctAnswer ? 'text-emerald-700' : 'text-rose-700'}`}>{examAnswers[index] === question.correctAnswer ? 'Correct.' : `Review: ${question.explanation}`}</p>}</div>)}<div className="flex items-center justify-between card p-5"><p className="font-semibold">{examSubmitted ? `Score: ${score}/${chapterQuestions.length}` : 'Answer every question, then submit.'}</p><button onClick={() => setExamSubmitted(true)} className="btn-primary">{examSubmitted ? 'Submitted' : 'Submit MCQ Test'}</button></div></div> : <WrittenSheet chapter={selectedChapter} />}</section>}

        {tab === 'vault' && <PaperVault papers={papers} onOpen={setSelectedPaper} />}
      </main>
      {selectedPaper && <PaperModal paper={selectedPaper} onClose={() => setSelectedPaper(null)} onDownload={() => downloadPaper(selectedPaper)} />}
    </div>
  );
}

function ChapterHeader({ chapter }: { chapter: SSLCChapter }) {
  return <div className="card p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"><div><p className="text-xs uppercase tracking-wider text-amber-600 font-semibold">Chapter {chapter.chapter_number} · {chapter.language}</p><h2 className="text-2xl font-heading font-bold mt-1">{chapter.title}</h2><p className="text-sm text-slate-500 mt-2 max-w-3xl">{chapter.summary}</p></div><div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center"><BookOpen className="w-6 h-6 text-amber-600" /></div></div>;
}

function ChapterPager({ chapters, selected, onSelect }: { chapters: SSLCChapter[]; selected: SSLCChapter; onSelect: (chapter: SSLCChapter) => void }) {
  const index = chapters.findIndex((chapter) => chapter.id === selected.id);
  return <div className="flex items-center justify-between"><button disabled={index <= 0} onClick={() => onSelect(chapters[index - 1])} className="btn-ghost flex items-center gap-2 disabled:opacity-40"><ChevronLeft className="w-4 h-4" /> Previous chapter</button><span className="text-sm text-slate-500">{index + 1} of {chapters.length}</span><button disabled={index === chapters.length - 1} onClick={() => onSelect(chapters[index + 1])} className="btn-ghost flex items-center gap-2 disabled:opacity-40">Next chapter <ChevronRight className="w-4 h-4" /></button></div>;
}

function QuestionCard({ item, shown, onToggle }: { item: AssignmentQuestion; shown: boolean; onToggle: () => void }) {
  return <div className="rounded-xl border border-slate-200 p-4 mb-3 last:mb-0"><div className="flex gap-3"><span className="w-7 h-7 rounded-lg bg-slate-950 text-amber-300 flex items-center justify-center text-xs font-bold flex-shrink-0">{item.marks}</span><p className="font-semibold text-slate-800 leading-relaxed flex-1">{item.question}</p></div><div className="mt-4 flex items-center gap-3"><button onClick={onToggle} className="btn-primary inline-flex items-center gap-2"><Eye className="w-4 h-4" /> {shown ? 'Hide Answer' : 'Show Answer'}</button><span className="text-xs text-slate-400">Self-check card</span></div>{shown && <div className="mt-4 grid md:grid-cols-2 gap-3"><div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200"><p className="text-xs uppercase tracking-wider text-emerald-700 font-bold mb-2">Model answer</p><p className="text-sm text-emerald-950 leading-relaxed">{item.answer}</p></div><div className="p-4 rounded-xl bg-amber-50 border border-amber-200"><p className="text-xs uppercase tracking-wider text-amber-700 font-bold mb-2">How marks are earned</p><p className="text-sm text-amber-950 leading-relaxed">{item.explanation}</p></div></div>}</div>;
}

function WrittenSheet({ chapter }: { chapter: SSLCChapter }) {
  return <div className="card p-6"><div className="flex items-center gap-3 mb-5"><FileText className="w-6 h-6 text-amber-600" /><div><h3 className="font-heading font-bold text-xl">Descriptive written exam sheet</h3><p className="text-sm text-slate-500">Use the mark allocation to plan handwriting space and answer depth.</p></div></div><div className="space-y-4">{[2, 3, 5].map((marks) => <div key={marks} className="p-5 rounded-xl border border-slate-200"><div className="flex items-center justify-between"><span className="font-bold text-slate-900">{marks} marks</span><span className="text-xs text-amber-700 font-semibold">Suggested response: {marks === 5 ? '12–15 lines' : `${marks * 2}–${marks * 3} lines`}</span></div><p className="font-semibold text-slate-800 mt-3">Explain one important concept from {chapter.title} using the correct terms and an example.</p><div className="mt-4 h-16 rounded-lg border border-dashed border-slate-300 bg-slate-50" /><p className="text-xs text-slate-500 mt-2">Model configuration: introduction → points or working → conclusion.</p></div>)}</div></div>;
}

function PaperVault({ papers, onOpen }: { papers: SSLCPaper[]; onOpen: (paper: SSLCPaper) => void }) {
  const [paperType, setPaperType] = useState<SSLCPaper['paper_type']>('main');
  const visible = papers.filter((paper) => paper.paper_type === paperType);
  return <section className="card p-6 sm:p-8"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6"><div><p className="text-xs uppercase tracking-wider text-amber-600 font-semibold">Document vault</p><h2 className="text-2xl font-heading font-bold mt-1">Question Paper Vault</h2><p className="text-sm text-slate-500 mt-1">Open, review, and save structured SSLC papers.</p></div><div className="w-12 h-12 rounded-xl bg-slate-950 flex items-center justify-center"><LockKeyhole className="w-5 h-5 text-amber-300" /></div></div><div className="flex flex-wrap gap-2 mb-6">{([{ id: 'main', label: '2023–2025 Main' }, { id: 'supplementary', label: 'Supplementary' }, { id: 'model', label: 'Model Papers' }, { id: 'topper', label: "Topper Scripts" }] as const).map((item) => <button key={item.id} onClick={() => setPaperType(item.id)} className={`px-4 py-2 rounded-xl text-sm font-semibold ${paperType === item.id ? 'bg-slate-950 text-amber-300' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>{item.label}</button>)}</div>{paperType === 'topper' ? <div className="grid sm:grid-cols-2 gap-4">{['Mathematics presentation guide', 'Science labelled-diagram guide', 'Social Science answer structure', 'Language essay presentation'].map((title) => <button key={title} onClick={() => onOpen({ id: title, subject: 'SSLC', year: 2025, paper_type: 'topper', title, description: 'High-scoring answer layout reference with margin, heading, diagram, and conclusion guidance.', questions: [{ marks: 5, type: 'Presentation guide' }], answer_script_url: null })} className="p-5 rounded-xl border border-slate-200 flex items-start gap-3 text-left hover:border-amber-300"><Trophy className="w-5 h-5 text-amber-500 mt-0.5" /><div><h3 className="font-semibold">{title}</h3><p className="text-sm text-slate-500 mt-1">Open gallery reference</p></div></button>)}</div> : <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{visible.map((paper) => <button key={paper.id} onClick={() => onOpen(paper)} className="p-5 rounded-xl border border-slate-200 text-left hover:border-amber-300 hover:shadow-sm transition-all"><CalendarDays className="w-5 h-5 text-amber-600 mb-3" /><h3 className="font-heading font-bold">{paper.year} {paper.paper_type === 'main' ? 'Main' : paper.paper_type === 'supplementary' ? 'Supplementary' : 'Model'} Paper</h3><p className="text-xs text-slate-500 mt-1">{paper.subject} · 1, 2, 3, and 5 mark sections</p><span className="inline-flex items-center gap-1 text-xs text-amber-700 font-semibold mt-4">Open document <Play className="w-3 h-3" /></span></button>)}</div>}</section>;
}

function PaperModal({ paper, onClose, onDownload }: { paper: SSLCPaper; onClose: () => void; onDownload: () => void }) {
  return <div className="fixed inset-0 z-50 bg-slate-950/70 p-4 sm:p-8 flex items-center justify-center"><div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"><div className="p-5 border-b border-slate-200 flex items-start justify-between gap-4"><div><p className="text-xs uppercase tracking-wider text-amber-600 font-bold">KHBV.D document viewer</p><h2 className="text-xl font-heading font-bold mt-1">{paper.title}</h2><p className="text-sm text-slate-500 mt-1">{paper.subject} · {paper.year}</p></div><button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100"><X className="w-5 h-5" /></button></div><div className="p-5 space-y-4"><div className="p-5 rounded-xl bg-slate-950 text-white border border-amber-500/50"><p className="text-amber-300 font-bold">Karnataka SSLC Board Practice</p><p className="text-sm text-slate-300 mt-2">{paper.description}</p></div>{paper.questions.map((question) => <div key={`${question.marks}-${question.type}`} className="p-4 rounded-xl border border-slate-200 flex items-center justify-between"><span className="font-semibold text-slate-800">{question.type}</span><span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-sm font-bold">{question.marks} marks</span></div>)}<p className="text-sm text-slate-500">The viewer preserves the paper structure so learners can practise the right answer length and marking pattern.</p></div><div className="p-5 border-t border-slate-200 flex gap-3"><button onClick={onDownload} className="btn-primary flex items-center gap-2"><Download className="w-4 h-4" /> Save paper</button><button onClick={onClose} className="btn-secondary">Close</button></div></div></div>;
}
