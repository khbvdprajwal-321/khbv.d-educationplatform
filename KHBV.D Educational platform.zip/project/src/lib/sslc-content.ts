import type { Question } from '@/lib/types';

export interface SSLCChapter {
  id: string;
  subject: string;
  chapter_number: number;
  title: string;
  language: string;
  summary: string;
  key_points: string[];
  formulas: string[];
  literature: { story_focus?: string; poem_focus?: string };
}

export interface SSLCPaper {
  id: string;
  subject: string;
  year: number;
  paper_type: 'main' | 'supplementary' | 'model' | 'topper';
  title: string;
  description: string;
  questions: { marks: number; type: string }[];
  answer_script_url: string | null;
}

const chapterTitles: Record<string, string[]> = {
  English: ['A Letter to God', 'Nelson Mandela: Long Walk to Freedom', 'Two Stories about Flying', 'From the Diary of Anne Frank', 'Glimpses of India', 'Mijbil the Otter', 'Madam Rides the Bus', 'The Sermon at Benares', 'The Proposal', 'Dust of Snow', 'Fire and Ice', 'A Tiger in the Zoo', 'How to Tell Wild Animals', 'The Ball Poem', 'Amanda!', 'The Trees', 'Fog', 'The Tale of Custard the Dragon', 'For Anne Gregory'],
  Kannada: ['Kuvempu Parichaya', 'Bettada Mele', 'Hakki Haraduttide', 'Mankuthimmana Kagga', 'Nanna Guri', 'Hakki Mattu Huli', 'Kereya Neeranu Kerege', 'Baalina Belaku', 'Kannada Nudi', 'Janapada Geethegalu'],
  Hindi: ['बड़े भाई साहब', 'डायरी का एक पन्ना', 'तताँरा-वामीरो कथा', 'तीसरी कसम के शिल्पकार शैलेंद्र', 'अब कहाँ दूसरे के दुख से दुखी होने वाले', 'पतझर में टूटी पत्तियाँ', 'कारतूस', 'साखी', 'मनुष्यता', 'पर्वत प्रदेश में पावस', 'कर चले हम फ़िदा', 'आत्मत्राण'],
  Sanskrit: ['शुचिपर्यावरणम्', 'बुद्धिर्बलवती सदा', 'व्यायामः सर्वदा पथ्यः', 'जननी तुल्यवत्सला', 'सुभाषितानि', 'सौहार्दं प्रकृतेः शोभा', 'विचित्रः साक्षी', 'सूक्तयः', 'भूकम्पविभीषिका', 'प्राणेभ्योऽपि प्रियः सुहृद्'],
  Mathematics: ['Real Numbers', 'Polynomials', 'Pair of Linear Equations in Two Variables', 'Quadratic Equations', 'Arithmetic Progressions', 'Triangles', 'Coordinate Geometry', 'Introduction to Trigonometry', 'Some Applications of Trigonometry', 'Circles', 'Areas Related to Circles', 'Surface Areas and Volumes', 'Statistics', 'Probability'],
  Science: ['Chemical Reactions and Equations', 'Acids, Bases and Salts', 'Metals and Non-metals', 'Carbon Compounds', 'Periodic Classification of Elements', 'Life Processes', 'Control and Coordination', 'How do Organisms Reproduce?', 'Heredity and Evolution', 'Light: Reflection and Refraction', 'The Human Eye and the Colourful World', 'Electricity', 'Magnetic Effects of Electric Current', 'Sources of Energy', 'Our Environment', 'Sustainable Management of Natural Resources'],
  'Social Science': ['India and the Contemporary World', 'The Nationalist Movement in Indo-China', 'Nationalism in India', 'The Making of a Global World', 'Print Culture and the Modern World', 'Resources and Development', 'Forest and Wildlife Resources', 'Water Resources', 'Agriculture', 'Manufacturing Industries', 'Lifelines of National Economy', 'Power Sharing', 'Federalism', 'Gender, Religion and Caste', 'Popular Struggles and Movements', 'Political Parties', 'Outcomes of Democracy', 'Challenges to Democracy', 'Development', 'Sectors of the Indian Economy', 'Money and Credit', 'Globalisation and the Indian Economy', 'Consumer Rights'],
};

const subjectLanguage: Record<string, string> = { Kannada: 'Kannada', Hindi: 'Hindi', Sanskrit: 'Sanskrit' };
const subjectSummary: Record<string, string> = {
  Mathematics: 'Concepts, formulas, worked examples, and board-style applications for Karnataka SSLC.',
  Science: 'Definitions, diagrams, experiments, equations, and everyday applications for Karnataka SSLC.',
  'Social Science': 'History, geography, civics, economics, map work, and answer-writing practice for Karnataka SSLC.',
  English: 'Prose, poetry, grammar, writing skills, and evidence-based literature answers.',
  Kannada: 'ಗದ್ಯ, ಪದ್ಯ, ವ್ಯಾಕರಣ ಮತ್ತು ಪ್ರಬಂಧ ಬರವಣಿಗೆಯ ಕ್ರಮಬದ್ಧ ಅಭ್ಯಾಸ.',
  Hindi: 'गद्य, पद्य, व्याकरण और लेखन कौशल का क्रमबद्ध अभ्यास।',
  Sanskrit: 'पाठ, श्लोक, अनुवाद, व्याकरण और रचनात्मक लेखन का क्रमबद्ध अभ्यास।',
};

function makeChapter(subject: string, title: string, chapterNumber: number): SSLCChapter {
  const language = subjectLanguage[subject] || 'English';
  const languagePoints = language === 'Kannada'
    ? ['ಪಾಠದ ಸಾರಾಂಶ', 'ಪಾತ್ರಚಿತ್ರಣ ಮತ್ತು ಘಟನೆಗಳ ಕ್ರಮ', 'ಪದ್ಯದ ಭಾವಾರ್ಥ', 'ವ್ಯಾಕರಣ ಮತ್ತು ಬರವಣಿಗೆ']
    : language === 'Hindi'
      ? ['पाठ का सारांश', 'पात्र-चित्रण और घटनाक्रम', 'पद्यांश का भावार्थ', 'व्याकरण और लेखन']
      : language === 'Sanskrit'
        ? ['पाठ का सरलार्थ', 'पदच्छेद और अन्वय', 'श्लोक का तात्पर्य', 'व्याकरण और अनुवाद']
        : ['Central idea and context', 'Character, theme, and evidence', 'Vocabulary and literary devices', 'Grammar and answer presentation'];
  const commonPoints = subject === 'Mathematics'
    ? ['Definition and conditions', 'Formula selection', 'Worked example with all steps', 'Common board-exam mistakes']
    : subject === 'Science'
      ? ['Key definition and principle', 'Labelled diagram or equation', 'Cause, effect, and application', 'Three-mark and five-mark answer frame']
      : subject === 'Social Science'
        ? ['Key terms and dates', 'Cause-and-effect chain', 'Map or example connection', 'Point-wise board answer structure']
        : languagePoints;
  return {
    id: `${subject}-${chapterNumber}`,
    subject,
    chapter_number: chapterNumber,
    title,
    language,
    summary: `${title}: ${subjectSummary[subject]}`,
    key_points: commonPoints,
    formulas: subject === 'Mathematics' ? ['Write the known values first.', 'Substitute into the correct formula.', 'Show every simplification line.', 'Box the final answer with units where required.'] : subject === 'Science' ? ['Use the chapter equation or law.', 'Define the terms before applying them.', 'Add a neat labelled diagram when the question asks for one.'] : [],
    literature: language !== 'English' || ['English'].includes(subject) ? {
      story_focus: language === 'English' ? 'Read the event sequence, then write a 4-part response: context, evidence, interpretation, and conclusion.' : 'Write the lesson sequence in your own words, explain the important character or idea, and support the answer with a textual detail.',
      poem_focus: language === 'English' ? 'Explain the speaker, image, tone, poetic device, and message in separate sentences.' : 'Write the stanza meaning, important words, poetic image, and message in clear language.',
    } : {},
  };
}

export const sslcSubjects = Object.keys(chapterTitles);
export const localSSLCChapters: SSLCChapter[] = sslcSubjects.flatMap((subject) => chapterTitles[subject].map((title, index) => makeChapter(subject, title, index + 1)));

export function getLocalChapters(subject: string): SSLCChapter[] {
  return localSSLCChapters.filter((chapter) => chapter.subject === subject);
}

export function getLocalPapers(subject: string): SSLCPaper[] {
  return [2025, 2024, 2023].flatMap((year) => (['main', 'supplementary', 'model'] as const).map((paperType) => ({
    id: `${subject}-${year}-${paperType}`,
    subject,
    year,
    paper_type: paperType,
    title: `${year} ${paperType === 'main' ? 'Main' : paperType === 'supplementary' ? 'Supplementary' : 'Model'} Paper`,
    description: `Karnataka SSLC ${subject} paper with 1, 2, 3, and 5 mark sections.`,
    questions: [{ marks: 1, type: 'MCQ' }, { marks: 2, type: 'Short answer' }, { marks: 3, type: 'Analytical' }, { marks: 5, type: 'Long answer' }],
    answer_script_url: null,
  })));
}

export function getChapterLesson(chapter: SSLCChapter): string[] {
  return [
    `Begin with the meaning of ${chapter.title} and connect it to the chapter summary.`,
    `Study these focus points: ${chapter.key_points.join('; ')}.`,
    chapter.formulas.length ? `Use the working guide: ${chapter.formulas.join(' ')}` : 'Build the answer from a definition, two supporting details, and a concluding line.',
    chapter.literature.story_focus || 'Finish by writing one board-style answer without looking at the notes, then compare it with the model structure.',
  ];
}

export function getChapterQuestions(chapter: SSLCChapter): Question[] {
  return [
    { id: chapter.chapter_number * 10 + 1, subject: chapter.subject, topic: chapter.title, difficulty: 'easy', question: `Which approach gives the strongest first step for ${chapter.title}?`, options: ['Copy a final answer only', 'Identify the concept and the question demand', 'Skip the chapter heading', 'Memorise without examples'], correctAnswer: 1, explanation: `Start by identifying the central concept in ${chapter.title}, then match the requested marks to the amount of evidence or working required.`, yearAsked: 2025 },
    { id: chapter.chapter_number * 10 + 2, subject: chapter.subject, topic: chapter.title, difficulty: 'medium', question: `Write a board-ready response about ${chapter.title}. What should it contain?`, options: ['Only a one-word response', 'Definition or context, supporting points, and a conclusion', 'Unrelated facts', 'A copied question'], correctAnswer: 1, explanation: 'A strong answer follows the marking demand: direct response first, supporting explanation or working next, and a clear concluding statement.', yearAsked: 2024 },
    { id: chapter.chapter_number * 10 + 3, subject: chapter.subject, topic: chapter.title, difficulty: 'difficult', question: `How should you revise ${chapter.title} before the SSLC board examination?`, options: ['Read once and stop', 'Combine recall, written practice, and error review', 'Study only the answer key', 'Avoid timed work'], correctAnswer: 1, explanation: 'Use three passes: understand the lesson, retrieve it without notes, and apply it in timed board-style questions while correcting mistakes.', yearAsked: 2023 },
  ];
}
