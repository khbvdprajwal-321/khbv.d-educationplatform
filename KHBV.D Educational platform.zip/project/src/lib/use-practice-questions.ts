import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { PracticeQuestion, PracticeTrack } from '@/lib/types';

export function usePracticeQuestions(track: PracticeTrack) {
  const [questions, setQuestions] = useState<PracticeQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    supabase
      .from('practice_questions')
      .select('*')
      .eq('track', track)
      .order('year_asked', { ascending: false })
      .then(({ data, error: queryError }) => {
        if (!active) return;
        if (queryError || !Array.isArray(data)) {
          setQuestions([]);
          setError('We could not load questions right now. Please try again shortly.');
        } else {
          setQuestions(data as PracticeQuestion[]);
        }
        setLoading(false);
      });
    return () => { active = false; };
  }, [track]);

  return { questions, loading, error };
}
