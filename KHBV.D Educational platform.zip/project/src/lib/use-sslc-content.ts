import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { getLocalChapters, getLocalPapers, type SSLCChapter, type SSLCPaper } from '@/lib/sslc-content';

export function useSSLCContent(subject: string) {
  const [chapters, setChapters] = useState<SSLCChapter[]>(() => getLocalChapters(subject));
  const [papers, setPapers] = useState<SSLCPaper[]>(() => getLocalPapers(subject));
  const [loading, setLoading] = useState(true);
  const [sourceError, setSourceError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    Promise.all([
      supabase.from('sslc_chapters').select('*').eq('subject', subject).order('chapter_number'),
      supabase.from('sslc_papers').select('*').eq('subject', subject).order('year', { ascending: false }),
    ]).then(([chapterResult, paperResult]) => {
      if (!active) return;
      const localChapters = getLocalChapters(subject);
      const remoteChapters = (chapterResult.data || []) as SSLCChapter[];
      const chapterMap = new Map(localChapters.map((chapter) => [chapter.chapter_number, chapter]));
      remoteChapters.forEach((chapter) => chapterMap.set(chapter.chapter_number, { ...chapterMap.get(chapter.chapter_number), ...chapter }));
      setChapters([...chapterMap.values()].sort((a, b) => a.chapter_number - b.chapter_number));
      const remotePapers = (paperResult.data || []) as SSLCPaper[];
      setPapers(remotePapers.length ? remotePapers : getLocalPapers(subject));
      setSourceError(chapterResult.error || paperResult.error ? 'Showing the complete built-in study catalogue while the shared vault reconnects.' : null);
      setLoading(false);
    });
    return () => { active = false; };
  }, [subject]);

  return { chapters, papers, loading, sourceError };
}
