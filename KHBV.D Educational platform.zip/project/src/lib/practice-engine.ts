import type { PracticeQuestion, PracticeTrack } from '@/lib/types';

export const PRACTICE_TRACKS: { id: PracticeTrack; label: string }[] = [
  { id: 'cet', label: 'CET' },
  { id: 'neet', label: 'NEET' },
  { id: 'jee', label: 'JEE' },
  { id: 'degree', label: 'Degree' },
];

export const DAILY_SET_SIZE = 5;
export const ASSIGNMENT_SET_SIZE = 3;
export const MOCK_TEST_SIZE = 20;
export const MOCK_SECONDS_PER_QUESTION = 20;

export type PracticeMode = 'daily' | 'assignment' | 'mock';

export function isPracticeMode(value: string): value is PracticeMode {
  return value === 'daily' || value === 'assignment' || value === 'mock';
}

export function isPracticeTrack(value: string): value is PracticeTrack {
  return PRACTICE_TRACKS.some((track) => track.id === value);
}

export function filterByYear(pool: PracticeQuestion[], year: number | null): PracticeQuestion[] {
  return year === null ? pool : pool.filter((question) => question.year_asked === year);
}

export function availableYears(pool: PracticeQuestion[]): number[] {
  const years = new Set<number>();
  pool.forEach((question) => {
    if (question.year_asked !== null) years.add(question.year_asked);
  });
  return [...years].sort((a, b) => b - a);
}

export function pickRandomQuestions(pool: PracticeQuestion[], count: number): PracticeQuestion[] {
  const shuffled = [...pool];
  for (let i = shuffled.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled.slice(0, count);
}
