import { useCallback, useEffect, useState } from 'react';
import { Clock, Medal, RotateCcw } from 'lucide-react';
import { QuestionCard } from '@/components/practice/QuestionCard';
import { MOCK_SECONDS_PER_QUESTION } from '@/lib/practice-engine';
import type { PracticeQuestion } from '@/lib/types';

interface MockTestProps {
  questions: PracticeQuestion[];
  onRetake: () => void;
  onExit: () => void;
}

export function MockTest({ questions, onRetake, onExit }: MockTestProps) {
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState(MOCK_SECONDS_PER_QUESTION);
  const [finished, setFinished] = useState(false);

  const isLast = index === questions.length - 1;

  const moveOn = useCallback(() => {
    if (index < questions.length - 1) {
      setIndex(index + 1);
      setTimeLeft(MOCK_SECONDS_PER_QUESTION);
    } else {
      setFinished(true);
    }
  }, [index, questions.length]);

  useEffect(() => {
    if (finished) return;
    const timer = window.setInterval(() => setTimeLeft((seconds) => Math.max(seconds - 1, 0)), 1000);
    return () => window.clearInterval(timer);
  }, [finished, index]);

  useEffect(() => {
    if (!finished && timeLeft === 0) moveOn();
  }, [timeLeft, finished, moveOn]);

  const selectAnswer = (optionIndex: number) => {
    setAnswers((previous) => ({ ...previous, [index]: optionIndex }));
  };

  const score = questions.reduce((total, question, i) => total + (answers[i] === question.correct_index ? 1 : 0), 0);
  const progress = ((index + 1) / questions.length) * 100;
  const timerColor = timeLeft <= 5 ? 'text-rose-600' : timeLeft <= 10 ? 'text-amber-600' : 'text-teal-700';

  if (finished) {
    return (
      <div className="space-y-4">
        <div className="card p-6 sm:p-8 text-center animate-scale-in">
          <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-4">
            <Medal className="w-8 h-8 text-amber-600" />
          </div>
          <h2 className="text-2xl font-heading font-bold text-slate-900">Mock test complete</h2>
          <p className="text-3xl font-heading font-bold text-teal-700 mt-2">{score} / {questions.length}</p>
          <p className="text-sm text-slate-500 mt-1">
            {Object.keys(answers).length} answered, {questions.length - Object.keys(answers).length} timed out
          </p>
          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <button type="button" onClick={onRetake} className="btn-primary flex-1 flex items-center justify-center gap-2">
              <RotateCcw className="w-4 h-4" /> Take a New Mock Test
            </button>
            <button type="button" onClick={onExit} className="btn-secondary flex-1">Back to Practice</button>
          </div>
        </div>

        <h3 className="font-heading font-bold text-lg text-slate-900 pt-2">All answers</h3>
        {questions.map((question, i) => (
          <QuestionCard key={question.id} question={question} number={i + 1} selected={answers[i]} revealed />
        ))}
      </div>
    );
  }

  const question = questions[index];

  return (
    <div className="space-y-4">
      <div className="card p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-slate-700">Question {index + 1} of {questions.length}</span>
          <div className={`flex items-center gap-2 font-heading font-bold text-lg ${timerColor} ${timeLeft <= 5 ? 'animate-pulse' : ''}`}>
            <Clock className="w-5 h-5" />
            {timeLeft}s
          </div>
        </div>
        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div className="h-full bg-teal-500 rounded-full transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <QuestionCard
        key={question.id}
        question={question}
        number={index + 1}
        selected={answers[index]}
        revealed={false}
        onSelect={selectAnswer}
      />

      <div className="flex items-center justify-between gap-3">
        <button type="button" onClick={onExit} className="btn-ghost text-sm">Leave test</button>
        <button type="button" onClick={moveOn} className="btn-primary">
          {isLast ? 'Finish Test' : 'Next Question'}
        </button>
      </div>
    </div>
  );
}
