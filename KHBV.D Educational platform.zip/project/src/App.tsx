import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth-context';
import { LandingPage } from '@/pages/LandingPage';
import { AuthPage } from '@/pages/AuthPage';
import { OnboardingPage } from '@/pages/OnboardingPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { ExamPage } from '@/pages/ExamPage';
import { ResultsPage } from '@/pages/ResultsPage';
import { SubjectPage } from '@/pages/SubjectPage';
import { DegreeFlowPage } from '@/pages/DegreeFlowPage';
import { ResumeAnalysisPage } from '@/pages/ResumeAnalysisPage';
import { PricingPage } from '@/pages/PricingPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { HomeworkPage } from '@/pages/HomeworkPage';
import { AssistantPage } from '@/pages/AssistantPage';
import { PracticePage } from '@/pages/PracticePage';

type Route =
  | { name: 'landing' }
  | { name: 'auth'; mode: 'login' | 'register' }
  | { name: 'onboarding' }
  | { name: 'dashboard' }
  | { name: 'subject'; subject: string }
  | { name: 'homework'; subject: string }
  | { name: 'exam'; subject: string; examType: string }
  | { name: 'results'; attemptId: string }
  | { name: 'degree' }
  | { name: 'resume' }
  | { name: 'pricing' }
  | { name: 'profile' }
  | { name: 'assistant' }
  | { name: 'practice'; track: string; mode: string };

function parseHash(): Route {
  const hash = window.location.hash.slice(1) || '/';
  const parts = hash.split('/').filter(Boolean);

  if (parts.length === 0 || parts[0] === 'home') return { name: 'landing' };
  if (parts[0] === 'auth') return { name: 'auth', mode: (parts[1] as 'login' | 'register') || 'login' };
  if (parts[0] === 'onboarding') return { name: 'onboarding' };
  if (parts[0] === 'dashboard') return { name: 'dashboard' };
  if (parts[0] === 'subject' && parts[1]) return { name: 'subject', subject: decodeURIComponent(parts[1]) };
  if (parts[0] === 'homework' && parts[1]) return { name: 'homework', subject: decodeURIComponent(parts[1]) };
  if (parts[0] === 'exam' && parts[1] && parts[2]) return { name: 'exam', subject: decodeURIComponent(parts[1]), examType: parts[2] };
  if (parts[0] === 'results' && parts[1]) return { name: 'results', attemptId: parts[1] };
  if (parts[0] === 'degree') return { name: 'degree' };
  if (parts[0] === 'resume') return { name: 'resume' };
  if (parts[0] === 'pricing') return { name: 'pricing' };
  if (parts[0] === 'profile') return { name: 'profile' };
  if (parts[0] === 'assistant') return { name: 'assistant' };
  if (parts[0] === 'practice') return { name: 'practice', track: parts[1] ? decodeURIComponent(parts[1]) : '', mode: parts[2] ?? '' };
  return { name: 'landing' };
}

export function navigate(route: string) {
  window.location.hash = route;
  window.scrollTo(0, 0);
}

export function App() {
  const { session, profile, loading } = useAuth();
  const [route, setRoute] = useState<Route>(parseHash());

  useEffect(() => {
    const onHashChange = () => setRoute(parseHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-teal-200 border-t-teal-600 rounded-full animate-spin" />
          <p className="text-slate-500 font-medium">Loading KHBV.D...</p>
        </div>
      </div>
    );
  }

  // Route guards
  const isAuthed = !!session;
  const needsOnboarding = isAuthed && !!profile && !profile.user_type;

  if (route.name === 'onboarding' && !isAuthed) {
    navigate('/auth/login');
    return null;
  }
  if ((route.name === 'dashboard' || route.name === 'subject' || route.name === 'homework' || route.name === 'exam' || route.name === 'results' || route.name === 'degree' || route.name === 'resume' || route.name === 'profile' || route.name === 'practice') && !isAuthed) {
    navigate('/auth/login');
    return null;
  }
  if (isAuthed && profile && route.name === 'landing') {
    navigate(needsOnboarding ? '/onboarding' : '/dashboard');
    return null;
  }
  if (needsOnboarding && route.name !== 'onboarding' && route.name !== 'auth' && route.name !== 'pricing') {
    navigate('/onboarding');
    return null;
  }

  switch (route.name) {
    case 'landing':
      return <LandingPage />;
    case 'auth':
      return <AuthPage mode={route.mode} />;
    case 'onboarding':
      return <OnboardingPage />;
    case 'dashboard':
      return <DashboardPage />;
    case 'subject':
      return <SubjectPage subject={route.subject} />;
    case 'homework':
      return <HomeworkPage subject={route.subject} />;
    case 'exam':
      return <ExamPage subject={route.subject} examType={route.examType} />;
    case 'results':
      return <ResultsPage attemptId={route.attemptId} />;
    case 'degree':
      return <DegreeFlowPage />;
    case 'resume':
      return <ResumeAnalysisPage />;
    case 'pricing':
      return <PricingPage />;
    case 'profile':
      return <ProfilePage />;
    case 'assistant':
      return <AssistantPage />;
    case 'practice':
      return <PracticePage key={`${route.track}-${route.mode}`} track={route.track} mode={route.mode} />;
    default:
      return <LandingPage />;
  }
}
